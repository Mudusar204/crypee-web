const PageNotExist = () => {
    return <>This page is not exist</>;
};

export default PageNotExist;
