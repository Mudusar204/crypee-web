// url.js
export const REACT_APP_BASE_URL = 'https://crypeebackend-production-82fa.up.railway.app';
// export const REACT_APP_BASE_URL = 'http://localhost:4000';
