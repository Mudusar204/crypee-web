export const url =
    process.env.NODE_ENV == 'production'
        ? 'https://crypeebackend-production-82fa.up.railway.app'
        : '';
